from text_to_speech import text_to_speech

text_to_speech("Mãos para o Alto! Você está preso! CAIA!","aaa.mp3")